# COMSOL在Apple Silicon上的表现

[MacBook Pro的CPU调度问题](https://quan.ithome.com/content/sharedetail?id=79461)

不使用全部核心，一般使用3或者4个。